use aula4exer6EvolucaoFinal;

drop table INFRACAO;
drop table TIPOINFRACAO;
drop table AGENTE;
drop table LOCAL;
drop table VEICULO;
drop table CATEGORIA;
drop table MODELO;
drop table telefone;
drop table PROPRIETARIO;
