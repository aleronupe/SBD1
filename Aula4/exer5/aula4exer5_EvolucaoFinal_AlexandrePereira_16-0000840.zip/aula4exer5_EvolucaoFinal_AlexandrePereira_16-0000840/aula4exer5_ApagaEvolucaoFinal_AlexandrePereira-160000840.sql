USE aula4exer5EvolucaoFinal;

drop table contem;
drop table MEDICAMENTO;
drop table RECEITA;
drop table CONSULTA;
drop table telefone;
drop table PACIENTE;
drop table possui;
drop table MEDICO;
drop table ESPECIALIDADE;
